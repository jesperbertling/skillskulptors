# SkillSkulptorProject
 Version 2 av projektet

 F�rgschema 
#6CBAD9 BL�
#D98B6C komplement- r�dbrun

