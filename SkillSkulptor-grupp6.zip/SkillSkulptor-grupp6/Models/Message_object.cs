﻿namespace SkillSkulptor.Models
{
	public class Message_object : Message
	{
		public string classCss { get; set; }
		public string MessageName { get; set; }
		public string ImageId { get; set; }

	}
}
