﻿namespace SkillSkulptor.Models
{
    public class EditSummaryLetterModel
    {
        public string? Summary { get; set; }
        public string? PersonalLetter { get; set; }
    }
}
